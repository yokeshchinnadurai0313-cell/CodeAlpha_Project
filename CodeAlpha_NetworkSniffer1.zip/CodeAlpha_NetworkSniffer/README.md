# CodeAlpha Basic Network Sniffer

A beginner-friendly Python network packet metadata analyzer created for the CodeAlpha Cyber Security Internship.

> **Safety:** Run this project only on your own device, an isolated lab, or a network for which you have explicit permission. The program displays packet metadata and does not intentionally save packet contents.

## Project objective

Build a Python program that captures a limited number of network packets and displays useful information such as:

- Source IP address
- Destination IP address
- Protocol
- Packet length

This follows the CodeAlpha internship description for the **Basic Network Sniffer** task, which mentions Python, Scapy/socket, packet capture, and displaying source/destination IPs and protocols.

## Technologies

- Python 3
- Scapy
- Windows + Npcap (if running on Windows)

## Project structure

```text
CodeAlpha_NetworkSniffer/
├── network_sniffer.py
├── requirements.txt
├── README.md
├── PROJECT_REPORT.md
└── screenshots/
```

## Installation on Windows

1. Install Python 3 from the official Python website.
2. During installation, enable **Add Python to PATH**.
3. Install Npcap from its official website. Use the normal installation options for a personal/lab machine.
4. Open Command Prompt or PowerShell in this project folder.
5. Install Scapy:

```bash
python -m pip install -r requirements.txt
```

## Run

On Windows, packet capture may require an elevated terminal. Open **Command Prompt as Administrator**, move to the project folder, then run:

```bash
python network_sniffer.py
```

The program captures 20 packets and prints a table of metadata.

## Example output

```text
Source IP        Destination IP   Protocol    Length
--------------------------------------------------------------
192.168.1.10     192.168.1.1      TCP            74 bytes
192.168.1.10     142.250.x.x      UDP            86 bytes
```

The addresses above are illustrative only.

## Testing

For a controlled demonstration, generate normal traffic from your own computer, such as opening a website you normally use, and observe the metadata. Do not capture traffic belonging to other people or networks without authorization.

Record screenshots showing:

1. Scapy installation completed.
2. The program running.
3. The packet table.
4. The final `Capture finished.` message.

## Limitations

- It is a learning/demo sniffer, not a full packet-analysis product.
- It captures a fixed number of packets.
- It displays metadata rather than storing packet payloads.
- Results depend on the network interface and traffic available during the test.

## Learning outcomes

- Basic packet capture
- IP addresses and protocols
- Python networking concepts
- Using Scapy
- Basic cybersecurity documentation

## Internship submission

Use a GitHub repository named:

`CodeAlpha_NetworkSniffer`

Include the source code, README, project report, and your test screenshots. Follow the submission form and LinkedIn/video instructions provided by CodeAlpha.
