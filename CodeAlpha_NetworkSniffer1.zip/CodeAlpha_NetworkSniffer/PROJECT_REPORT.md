# CodeAlpha Cyber Security Internship
## Basic Network Sniffer - Project Report

### 1. Introduction

A network sniffer is a program that captures network packets so that network activity can be observed and analyzed. This project implements a small Python-based packet metadata analyzer using Scapy.

### 2. Objective

The objectives are to:

- Capture a controlled number of network packets.
- Identify source and destination addresses.
- Identify common protocols.
- Display packet length.
- Understand basic network traffic flow.

### 3. Tools and technologies

- Python 3
- Scapy
- Npcap on Windows

### 4. Working principle

1. The program starts packet capture using Scapy's `sniff()` function.
2. Each captured packet is passed to a display function.
3. The program checks whether the packet contains IP or ARP information.
4. It identifies TCP, UDP, ICMP, ARP, or another protocol.
5. It displays source, destination, protocol, and packet length.
6. The program stops automatically after 20 packets.

### 5. Security and privacy considerations

The project is intended only for authorized testing. Packet capture can expose sensitive information on networks where the user does not have permission. Therefore, testing should be limited to the user's own device, an isolated lab, or an explicitly authorized network. The implementation does not intentionally save packet payloads.

### 6. Testing procedure

- Install Scapy from `requirements.txt`.
- Open an elevated terminal when required by the operating system.
- Start the sniffer.
- Generate ordinary traffic from the user's own machine.
- Confirm that packet metadata appears in the terminal.
- Confirm that the program stops after the configured packet count.

### 7. Expected result

The terminal should display rows containing source address, destination address, protocol, and packet length, followed by a capture completion message.

### 8. Limitations

This is an educational project. It is not intended to replace professional network-monitoring or intrusion-detection software. It does not provide a complete protocol decoder, persistent logging system, or attack-detection engine.

### 9. Conclusion

The project demonstrates the basic process of capturing and inspecting network packet metadata using Python and Scapy. It provides practical understanding of IP addresses, protocols, packet lengths, and network traffic flow while emphasizing authorized and privacy-conscious testing.
