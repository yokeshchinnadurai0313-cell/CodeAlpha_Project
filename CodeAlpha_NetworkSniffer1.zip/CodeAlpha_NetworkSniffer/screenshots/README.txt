Place your real testing screenshots in this folder before submitting the project.
Recommended screenshots: installation, running program, packet output, and completion message.
