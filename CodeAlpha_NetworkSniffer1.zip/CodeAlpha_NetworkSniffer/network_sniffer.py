"""CodeAlpha Cyber Security Internship - Basic Network Sniffer.

Captures a limited number of packets from an authorized interface and displays
metadata such as source/destination IPs, protocol, and packet length.
"""

from scapy.all import sniff, IP, TCP, UDP, ICMP, ARP


def protocol_name(packet):
    if packet.haslayer(TCP):
        return "TCP"
    if packet.haslayer(UDP):
        return "UDP"
    if packet.haslayer(ICMP):
        return "ICMP"
    if packet.haslayer(ARP):
        return "ARP"
    return "Other"


def show_packet(packet):
    proto = protocol_name(packet)
    length = len(packet)

    if packet.haslayer(IP):
        src = packet[IP].src
        dst = packet[IP].dst
    elif packet.haslayer(ARP):
        src = packet[ARP].psrc
        dst = packet[ARP].pdst
    else:
        src = "N/A"
        dst = "N/A"

    print(f"{src:<16} {dst:<16} {proto:<7} {length:>6} bytes")


def main():
    print("=" * 62)
    print("CodeAlpha - Basic Network Sniffer")
    print("Authorized/lab traffic only")
    print("=" * 62)
    print(f"{'Source IP':<16} {'Destination IP':<16} {'Protocol':<7} {'Length':>12}")
    print("-" * 62)

    try:
        # A small fixed count keeps the internship demo controlled.
        sniff(count=20, prn=show_packet, store=False)
    except PermissionError:
        print("Permission denied. On Windows, run the terminal as Administrator and ensure Npcap is installed.")
    except Exception as exc:
        print(f"Capture error: {exc}")

    print("\nCapture finished.")


if __name__ == "__main__":
    main()
