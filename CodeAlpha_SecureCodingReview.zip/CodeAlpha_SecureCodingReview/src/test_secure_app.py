"""Small checks for the secure coding demo."""
from pathlib import Path
import ast

def test_secure_code_parses():
    source = Path("src/secure_app.py").read_text(encoding="utf-8")
    ast.parse(source)

if __name__ == "__main__":
    test_secure_code_parses()
    print("PASS: secure_app.py parses successfully.")
