"""Secure coding example for local demonstration."""
import hashlib
import hmac
import sqlite3

DB = "users.db"

def validate_username(username):
    if not isinstance(username, str) or not 1 <= len(username) <= 50:
        raise ValueError("Username must be 1-50 characters.")
    if not username.replace("_", "").isalnum():
        raise ValueError("Username may contain letters, numbers, and underscores only.")

def find_user(username):
    validate_username(username)
    with sqlite3.connect(DB) as conn:
        return conn.execute(
            "SELECT username, role FROM users WHERE username = ?",
            (username,)
        ).fetchall()

def hash_password(password, salt):
    if not isinstance(password, str) or len(password) < 12:
        raise ValueError("Password must be at least 12 characters.")
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt, 600_000
    ).hex()

def verify_password(password, stored_hash, salt):
    candidate = hash_password(password, salt)
    return hmac.compare_digest(candidate, stored_hash)
