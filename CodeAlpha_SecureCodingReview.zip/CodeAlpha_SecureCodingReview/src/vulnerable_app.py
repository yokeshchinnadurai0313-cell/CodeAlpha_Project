# INSECURE DEMO - for local code-review practice only
import sqlite3
import hashlib

DB = "users.db"

def find_user(username):
    conn = sqlite3.connect(DB)
    query = "SELECT username, role FROM users WHERE username = '" + username + "'"
    rows = conn.execute(query).fetchall()
    conn.close()
    return rows

def register(username, password):
    conn = sqlite3.connect(DB)
    password_hash = hashlib.md5(password.encode()).hexdigest()
    conn.execute(
        "INSERT INTO users(username, password) VALUES ('" +
        username + "', '" + password_hash + "')"
    )
    conn.commit()
    conn.close()

# Security issues intentionally included for review:
# 1. SQL injection risk from string-built SQL.
# 2. MD5 is unsuitable for password storage.
# 3. No input validation or length limits.
# 4. Database errors are not handled safely.
