# CodeAlpha — Secure Coding Review

## Project
**Secure Coding Review** — CodeAlpha Cyber Security Internship

## Objective
Review a small Python application, identify security weaknesses, implement safer alternatives, and document the remediation steps.

This project follows CodeAlpha's internship requirement to select an application, perform a security-focused code review, document findings, and recommend remediation.

## Project structure
```text
CodeAlpha_SecureCodingReview/
├── src/
│   ├── vulnerable_app.py
│   ├── secure_app.py
│   └── test_secure_app.py
├── screenshots/
├── PROJECT_REPORT.md
├── README.md
└── requirements.txt
```

## Vulnerabilities reviewed
1. SQL injection risk from dynamically constructed SQL.
2. Weak password hashing using MD5.
3. Missing input validation and length limits.
4. Unsafe database-error handling practices.

## Remediation
- Use parameterized SQL queries.
- Use PBKDF2-HMAC-SHA256 for password hashing in this demonstration.
- Validate input and enforce sensible limits.
- Use controlled exception handling and avoid exposing sensitive database details.

## Run the demonstration
No third-party packages are required.

```bash
python src/test_secure_app.py
```

Expected result:
```text
PASS: secure_app.py parses successfully.
```

## Important
`vulnerable_app.py` intentionally contains insecure patterns for educational code-review purposes. Do not deploy it or use it with real credentials or production data.

## Internship deliverables
- Source code
- README
- Security review report
- Screenshots of testing
- GitHub repository
- Project explanation video
