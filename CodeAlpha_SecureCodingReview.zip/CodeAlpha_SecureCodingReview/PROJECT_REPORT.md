# Project Report — Secure Coding Review

## 1. Introduction
This project performs a security review of a small Python application. The goal is to identify common insecure coding practices, explain their security impact, and implement safer alternatives.

## 2. Objectives
- Inspect source code for security weaknesses.
- Identify the affected code and risk.
- Apply secure coding practices.
- Test the corrected code.
- Document findings and remediation.

## 3. Findings

### Finding 1 — SQL Injection Risk
**Location:** `src/vulnerable_app.py`, `find_user()`

**Issue:** User-controlled input is concatenated directly into an SQL statement.

**Risk:** Special SQL syntax in input can change the meaning of a query.

**Remediation:** Use a parameterized query with a placeholder and pass the username separately.

**Secure version:** `src/secure_app.py`, `find_user()`.

### Finding 2 — Weak Password Hashing
**Location:** `src/vulnerable_app.py`, `register()`

**Issue:** MD5 is used for password hashing.

**Risk:** MD5 is not designed for secure password storage and is too fast for this purpose.

**Remediation:** Use a password-specific, salted password hashing approach. This project demonstrates PBKDF2-HMAC-SHA256 with a high iteration count.

### Finding 3 — Missing Input Validation
**Location:** User-controlled `username` and `password` values.

**Issue:** No type, length, or format checks are performed.

**Risk:** Unexpected input can cause errors or increase attack surface.

**Remediation:** Validate the username and enforce a minimum password length.

### Finding 4 — Error Handling
**Issue:** The demonstration code does not show controlled handling of database failures.

**Risk:** Poorly handled errors can expose implementation details.

**Remediation:** In a production application, catch expected database exceptions, log appropriate diagnostic information securely, and return generic user-facing errors.

## 4. Secure Coding Principles Used
- Parameterized SQL queries
- Input validation
- Strong password hashing
- Separation of user-facing errors from internal diagnostics
- Least exposure of sensitive information

## 5. Testing
Run:

```bash
python src/test_secure_app.py
```

Expected output:

```text
PASS: secure_app.py parses successfully.
```

Additional manual checks:
- Confirm the secure SQL query uses placeholders.
- Confirm MD5 is absent from the secure implementation.
- Confirm username validation is present.
- Confirm password length validation is present.

## 6. Limitations
This is an educational code-review project, not a complete production authentication system. A real application would also require secure session management, authorization, secret management, rate limiting, logging, dependency management, and comprehensive automated tests.

## 7. Conclusion
The review demonstrates how insecure coding patterns can create security risks and how safer coding practices reduce those risks. The project provides both an intentionally insecure example for analysis and a corrected implementation for comparison.
