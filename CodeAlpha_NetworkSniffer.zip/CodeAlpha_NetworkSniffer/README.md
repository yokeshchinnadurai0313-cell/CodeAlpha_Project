# CodeAlpha Basic Network Sniffer

Cyber Security Internship project demonstrating basic packet capture and analysis with Python and Scapy, plus a self-contained learning website with sample packets and an interactive quiz.

## Files
- `network_sniffer.py` — captures up to 20 packets and displays source IP, destination IP, protocol and length.
- `index.html` — educational website and quiz.
- `PROJECT_REPORT.md` — internship report.

## Setup
1. Install Python 3.
2. Open a terminal in this folder.
3. Install Scapy: `python -m pip install scapy`
4. Run: `python network_sniffer.py`

Packet capture may require appropriate permissions or a capture driver depending on your operating system.

## Website
Open `index.html` in a browser. Its packet table contains fictional sample data for learning; it does not capture browser traffic.

## Evidence
Capture screenshots of the GitHub repository, website, quiz result, terminal execution and sample packet output. Do not expose credentials, private messages, or other people's sensitive traffic.

## Responsible use
Use packet capture only on your own device, an authorized lab, or a network for which you have explicit permission.
