# CodeAlpha Internship Project Report
## Basic Network Sniffer

### Objective
Build a beginner-friendly Python program that captures network packets and displays source IP, destination IP, protocol and packet length.

### Technologies
Python 3, Scapy, HTML, CSS and JavaScript.

### Components
**network_sniffer.py:** captures a limited number of packets and prints metadata.

**index.html:** provides a browser-based learning lab with sample packet data and a five-question interactive quiz.

### Working
1. Scapy listens for packets on an authorized interface.
2. The program checks for an IP layer.
3. It extracts source and destination IP addresses.
4. It identifies TCP, UDP and ICMP when present.
5. It prints packet length and stops after the configured count.

### Testing
Run the program on an authorized device or lab network and save screenshots showing successful execution and packet output.

### Security and ethics
Packet capture can expose sensitive information. Use the program only with authorization and keep private information out of internship evidence.

### Conclusion
The project demonstrates basic packet capture, protocol identification and network traffic analysis while providing an interactive learning interface.
