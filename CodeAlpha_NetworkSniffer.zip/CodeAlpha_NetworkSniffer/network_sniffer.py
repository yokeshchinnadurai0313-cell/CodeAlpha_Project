from scapy.all import sniff, IP
from datetime import datetime

PACKET_LIMIT = 20

def protocol_name(packet):
    if packet.haslayer("TCP"): return "TCP"
    if packet.haslayer("UDP"): return "UDP"
    if packet.haslayer("ICMP"): return "ICMP"
    return "Other"

def show_packet(packet):
    timestamp = datetime.now().strftime("%H:%M:%S")
    if packet.haslayer(IP):
        source = packet[IP].src
        destination = packet[IP].dst
        protocol = protocol_name(packet)
        print(f"{timestamp} | {source:<15} -> {destination:<15} | {protocol:<5} | {len(packet)} bytes")
    else:
        print(f"{timestamp} | Non-IP packet | {len(packet)} bytes")

def main():
    print("CodeAlpha Basic Network Sniffer")
    print(f"Capturing up to {PACKET_LIMIT} packets...")
    print("Use only on an authorized interface/network.\n")
    sniff(count=PACKET_LIMIT, prn=show_packet, store=False)
    print("\nCapture complete.")

if __name__ == "__main__": main()
