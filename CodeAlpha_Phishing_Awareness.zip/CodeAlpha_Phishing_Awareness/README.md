# PhishAware — Phishing Awareness Training

**Internship project:** CodeAlpha Cyber Security Internship — Task 2  
**Project type:** Responsive educational website with an interactive quiz  
**Technologies:** HTML, CSS, JavaScript

## Project overview

PhishAware teaches users how to recognize phishing messages and respond safely. It includes:

- Common phishing warning signs
- A suspicious-message training example
- A comparison of a suspicious message and a safer response
- Four practical safety habits
- A five-question interactive quiz with answer feedback, score, and restart option
- Responsive layout for desktop and mobile screens
- Light/dark color support based on the browser or device setting

## How to run

1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Scroll through the training sections and complete the quiz.

No server, package installation, or internet connection is required. The website is self-contained.

## Repository name

Suggested repository name: `CodeAlpha_PhishingAwarenessTraining`

## Suggested screenshots for your submission

Capture screenshots of:

1. Homepage and training introduction
2. Warning signs section
3. Example messages and prevention tips
4. Quiz question with feedback
5. Final quiz score

## Project explanation video outline

1. Introduce the project and its purpose.
2. Explain the phishing warning signs section.
3. Demonstrate the example and safety tips.
4. Answer quiz questions and show the score.
5. Explain that the project uses HTML for structure, CSS for design, and JavaScript for quiz interaction.

## Safety note

This is an awareness education project. The example domain `example.invalid` is intentionally non-operational. Do not use the site to collect credentials or send deceptive messages.

## Internship submission reminder

Review the current instructions from your internship coordinator. Upload your source code to GitHub and submit the project through the official form shared with your internship group. Only claim tests or screenshots you have actually completed yourself.
