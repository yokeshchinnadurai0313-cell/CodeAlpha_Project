# Project Report: PhishAware — Phishing Awareness Training

## 1. Introduction

Phishing is a form of social engineering in which an attacker impersonates a trusted person or organization to persuade someone to reveal sensitive information, make a payment, or take an unsafe action. Awareness training helps people recognize warning signs and verify unexpected requests.

## 2. Objective

The objective is to create a beginner-friendly website that explains phishing indicators, demonstrates a suspicious message, shares safer response habits, and checks understanding through an interactive quiz.

## 3. Technologies used

- **HTML:** Organizes the website content and sections.
- **CSS:** Provides responsive layout, colors, cards, buttons, and light/dark theme support.
- **JavaScript:** Displays quiz questions, checks answers, provides explanations, calculates a score, and restarts the quiz.

## 4. Main features

1. Introductory section explaining the website's purpose.
2. Warning signs including urgency, suspicious links, unexpected senders, requests for secrets, unusual wording, and unexpected attachments.
3. Example suspicious parcel message and a safer verification response.
4. Four habits: pause, inspect, verify, and report.
5. Five-question multiple-choice quiz with immediate feedback and final score.
6. Responsive layout for narrow and wide screens.

## 5. How the quiz works

The questions and answer options are stored in a JavaScript array. When a user chooses an option, the script checks it against the correct answer, disables the choices, displays feedback, and updates the score. The Next button advances through the questions. At the end, the website displays the result and allows the user to try again.

## 6. How to run the project

Open `index.html` in a modern web browser. No external libraries or network connection are required.

## 7. Testing checklist

Complete these checks before final submission and record your actual results:

- [ ] Website opens in a browser without requiring internet access.
- [ ] Navigation links move to the correct sections.
- [ ] All five quiz questions appear in order.
- [ ] Correct and incorrect answers show appropriate feedback.
- [ ] Score increases only for correct answers.
- [ ] Final score appears after question five.
- [ ] Restart and Try Again reset the quiz.
- [ ] Layout is readable on desktop and mobile.
- [ ] No real credential collection or external tracking is present.

## 8. Limitations

This is an educational static website. It does not scan real email, identify phishing links automatically, connect to a threat-intelligence service, or save quiz results to a server.

## 9. Conclusion

PhishAware provides a simple, interactive introduction to phishing awareness. It helps users practice recognizing suspicious messages and learn safer verification habits.

## 10. Submission evidence to add

Add your own screenshots, GitHub repository URL, project video URL, and internship details only after you have completed those steps. Do not report unperformed tests as completed.
